#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    if (timeelasped != 0) return;
    if (numblocks == 0) return;

    if (cnt == 0){
        scenes[0] = new QGraphicsScene;

        scenes[0]->addLine(0,maxheight-50,400,maxheight-50, QPen(Qt::white, 1));
        scenes[0]->addLine(0,maxheight,400,maxheight, QPen(Qt::white, 1));
        ui->graphicsView->setScene(scenes[0]);
        ui->graphicsView->setAlignment(Qt::AlignTop|Qt::AlignLeft); //26-11-2020
        //ui->graphicsView->setContentsMargins(0,0,0,0);

        //dummy
        rects[1] = scenes[0]->addRect(QRectF(0,0, 20,20));
        rects[1]->setBrush(QBrush(Qt::darkMagenta));
        //dummy

        //green
        rects[0] = scenes[0]->addRect(QRectF(defx, 0, 40, 10));
        rects[0]->setBrush(QBrush(Qt::darkGreen));
        rects[0]->setPen(QPen(Qt::darkBlue, 1));
        //green

        //yellow
        for (int i=0; i<=maxheight/50; ++i){
            rects[i+2] = scenes[0]->addRect(QRectF(350,i*50, 40,10));
            rects[i+2]->setBrush(QBrush(Qt::darkYellow));
            rects[i+2]->setPen(QPen(Qt::darkBlue, 1));
        }
        //yellow
        if (timer != nullptr)timer->stop();
        height = 0;

        timer = new QTimer;
        connect(timer, SIGNAL(timeout()), this, SLOT(mover()));
        timer->start(deltat);
    }
    else if (cnt == 1){
        scenes[1] = new QGraphicsScene;
        rects[1] = scenes[1]->addRect(QRectF(-100, -100, 50, 50));
        ui->graphicsView->setScene(scenes[1]);
        cnt--;
    }
    else{
        //now nothing here
    }
}

void MainWindow::mover(){

    if (cscene != 0) return;

    //green
    height += deltah;
    if (height >= maxheight){
        timer->stop();

        numblocks = 0;

        timeelasped = 0;
        ui->lcdNumber_2->display(timeelasped);
        return;
    }

    rects[0]->setRect(QRectF(defx, height, 40, 10));
    //ui->pushButton->setText(QString::number(height));
    //green

    //red
    for (int lnum=0; lnum<3; ++lnum){
        for (int bnum=lanestart[lnum]; bnum<laneend[lnum]; ++bnum){
            QRectF temp = blocks[lnum][bnum]->rect();
            temp.setRect(temp.x() , temp.y() +speed[lnum][bnum], temp.width(), temp.height() );

            if (temp.y()+speed[lnum][bnum] <= maxheight) {
                blocks[lnum][bnum]->setRect(temp);
            }
            else
            {
                qDebug() << "bad guy -250" << endl;
                score -= 250;
                ui->lcdNumber->display(score);

                scenes[0]->removeItem(blocks[lnum][bnum]);
                blocks[lnum][bnum] = nullptr;

                lanestart[lnum]++;
            }
        }
    }
    while (curblock < numblocks && btime[curblock] <= timeelasped){
        int lane = blane[curblock];

        blocks[lane][laneend[lane] ] = scenes[0]->addRect(QRectF( (lane+2)*50, 0, 40,10));
        blocks[lane][laneend[lane] ]->setBrush(QBrush(Qt::darkRed));
        blocks[lane][laneend[lane] ]->setPen(QPen(Qt::darkBlue, 1));

        speed[lane][laneend[lane] ] = bspeed[curblock];

        ++laneend[lane];
        ++curblock;
        qDebug() << timeelasped << " msces passed, time to add sth new" << endl;
    }
    //red
    timeelasped += deltat;
    ui->lcdNumber_2->display(timeelasped);
}

void MainWindow::stagesetup(){
    QFile file(":/texts/stage.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
        qDebug() << "no file ar\n";
        return;
    }

    for (int i=0; i<3; ++i){
        for (int j=0; j<5; ++j){
            if (blocks[i][j] != nullptr) {
                scenes[0]->removeItem(blocks[i][j]);
                blocks[i][j] = nullptr;
            }
            speed[i][j] = 0;
        }
    }
    timeelasped = 0;
    curblock = 0;
    for (int i=0; i<3; ++i){
        lanestart[i] = laneend[i] = 0;
    }

    QTextStream in(&file); //the stream name is in by this line
        in >> numblocks;
        qDebug() << "There are "  << numblocks << " blocks."<< endl;
        /*
        while (!in.atEnd()) {
            QString line = in.readLine();
            qDebug() << line << endl;
        }
        */
        for (int i=0; i<numblocks; ++i){
            in >> btime[i] >> blane[i] >> bspeed[i];
            qDebug() << btime[i] << " " << blane[i] << " " << bspeed[i] << endl;
        }
}

void MainWindow::on_pushButton_2_clicked()
{
    if (timeelasped == 0) stagesetup();
}

void MainWindow::keyPressEvent(QKeyEvent* ke){
    const int whichkey = ke->key();
    if (whichkey == Qt::Key_A){
        //score += 5;
        if (lanestart[0] == laneend[0]) return; //no blocks

        int nheight = blocks[0][lanestart[0]]->rect().y();
        if (nheight < maxheight-50){
            score -= 200;
        }else{
            //score update
            if (nheight >= maxheight-30) score += 2*nheight; //nice
            else score += 1.5*nheight; //ok
            qDebug() << "lane 1: height = " << nheight << endl;

            scenes[0]->removeItem(blocks[0][lanestart[0]]);
            blocks[0][lanestart[0]] = nullptr;
            lanestart[0]++;
        }
        ui->lcdNumber->display(score);
    }else if (whichkey == Qt::Key_S){
        //score -= 50;
        if (lanestart[1] == laneend[1]) return; //no blocks

        int nheight = blocks[1][lanestart[1]]->rect().y();

        if (nheight < maxheight-50){
            score -= 200;
        }else{
            //score update
            if (nheight >= maxheight-30) score += 2*nheight; //nice
            else score += 1.5*nheight; //ok
            qDebug() << "lane 2: height = " << nheight << endl;

            scenes[0]->removeItem(blocks[1][lanestart[1]]);
            blocks[1][lanestart[1]] = nullptr;
            lanestart[1]++;
        }

        ui->lcdNumber->display(score);
    }else if (whichkey == Qt::Key_D){
        //score += 50;
        if (lanestart[2] == laneend[2]) return; //no blocks

        int nheight = blocks[2][lanestart[2]]->rect().y();
        if (nheight < maxheight-50){
            score -= 200;
        }else{
            //score update
            if (nheight >= maxheight-30) score += 2*nheight; //nice
            else score += 1.5*nheight; //ok
            qDebug() << "lane 3: height = " << nheight << endl;

            scenes[0]->removeItem(blocks[2][lanestart[2]]);
            blocks[2][lanestart[2]] = nullptr;
            lanestart[2]++;
        }
        ui->lcdNumber->display(score);
    }
    else if (whichkey == Qt::Key_F){
        score = 2012;
        ui->lcdNumber->display(score);
    }
}

