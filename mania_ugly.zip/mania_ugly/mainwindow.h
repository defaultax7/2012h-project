#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsRectItem>
#include <QTimer>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QKeyEvent>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void keyPressEvent(QKeyEvent*);
private slots:
    void on_pushButton_clicked();
    void mover();

    void on_pushButton_2_clicked();
    //void keyPressEvent(QKeyEvent *event) override;
private:
    Ui::MainWindow *ui;
    QGraphicsRectItem *rects[100]{nullptr}, *blocks[3][5]{nullptr};
    QGraphicsScene *scenes[10];
    QTimer *timer{nullptr};

    int cnt{0}, numblocks{0}, timeelasped{0};
    int height{0}, defx{300}, cscene{0};
    int deltah{4}, deltat{60}; //change delta to change the pace of everything

    int btime[100], blane[100], bspeed[100], curblock{0};
    int lanestart[3] = {0,0,0};
    int laneend[3] = {0,0,0};
    int speed[3][5];
    int score{0};

    const int maxheight{500};
    void stagesetup();
};
#endif // MAINWINDOW_H
